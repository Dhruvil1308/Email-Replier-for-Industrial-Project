// Stream a draft from the local bridge via SSE-like fetch
async function requestDraft(emailBody, style = "concise, polite, <=120 words") {
  const res = await fetch("http://localhost:5000/draft", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: emailBody, style })
  });

  if (!res.body) {
    chrome.runtime.sendMessage({ type: "draft_error", error: "No stream body" });
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    const parts = buffer.split("\n\n");
    buffer = parts.pop() || "";
    for (const chunk of parts) {
      const line = chunk.trim();
      if (!line.startsWith("data:")) continue;
      try {
        const payload = JSON.parse(line.slice(5).trim());
        chrome.runtime.sendMessage(payload);
      } catch (_) {}
    }
  }
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "generateDraft") {
    requestDraft(msg.emailBody, msg.style);
  }
});