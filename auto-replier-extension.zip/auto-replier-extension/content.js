function extractGmail() {
  const nodes = document.querySelectorAll("div.a3s.aiL, div.a3s");
  let text = "";
  nodes.forEach(n => text += "\n" + (n.innerText || ""));
  return text.trim();
}

function extractOutlook() {
  const n = document.querySelector("[role='document']");
  return (n && n.innerText) ? n.innerText.trim() : "";
}

function detectAndSend() {
  let body = "";
  const host = window.location.host;
  if (host.includes("mail.google.com")) body = extractGmail();
  if (host.includes("outlook.office.com")) body = extractOutlook();
  if (body) {
    chrome.runtime.sendMessage({ type: "pageEmailExtracted", body });
  }
}

detectAndSend();
const obs = new MutationObserver(() => detectAndSend());
obs.observe(document.documentElement, { childList: true, subtree: true });