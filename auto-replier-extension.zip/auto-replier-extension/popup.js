const emailEl = document.getElementById("email");
const draftEl = document.getElementById("draft");
const styleEl = document.getElementById("style");
const genBtn = document.getElementById("gen");
const copyBtn = document.getElementById("copy");
const sendBtn = document.getElementById("send");

let draftAccum = "";

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "pageEmailExtracted") {
    if (!emailEl.value) emailEl.value = msg.body;
  } else if (msg.type === "partial") {
    draftAccum += msg.content;
    draftEl.value = draftAccum;
  } else if (msg.type === "final") {
    draftAccum = msg.content;
    draftEl.value = draftAccum;
  } else if (msg.type === "draft_error") {
    alert("Draft error: " + msg.error);
  }
});

genBtn.addEventListener("click", () => {
  draftAccum = "";
  chrome.runtime.sendMessage({
    type: "generateDraft",
    emailBody: emailEl.value.trim(),
    style: styleEl.value.trim() || "concise, polite, <=120 words"
  });
});

copyBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(draftEl.value);
  copyBtn.textContent = "Copied!";
  setTimeout(() => (copyBtn.textContent = "Copy"), 1200);
});

sendBtn.addEventListener("click", () => {
  alert("Enable Send after OAuth wiring per the PDF (gmail.send).");
});